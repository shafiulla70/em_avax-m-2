## Fuction Fronted 
create a simple contract with 2-3 functions. Then show the values of those functions in frontend of the application. You can use this starter template to get a head start.

## Functionality
Smart contract has at least two functions
Value of the functions from the smart contract are visible on the frontend of the application.

## TOOL USED
GITPOD
METAMASK
CHROME

## Application flow
Firstly, connect your wallet by clicking on connect wallet button.
Your balance will be updated automatically after each transaction.
You can deposit the balance into your account by clicking the deposit button.
You can withdraw funds using Withdraw button.


# Starter Next/Hardhat Project

After cloning the github, you will want to do the following to get the code running on your computer.
1. Inside the project directory, in the terminal type:` npm i `
2. Open two additional terminals in your VS code
3. In the second terminal type: `npx hardhat node`
4. In the third terminal, type:` npx hardhat run --network localhost scripts/deploy.js`
5. Back in the first terminal, type `npm run dev` to launch the front-end.

After this, the project will be running on your localhost. 
Typically at http://localhost:3000/

## AUTHOR
Himanshu Pal
Chandigarh University

